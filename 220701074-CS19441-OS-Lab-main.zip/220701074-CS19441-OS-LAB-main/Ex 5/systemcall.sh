cat hellotrace|cut -f1 -d"("
